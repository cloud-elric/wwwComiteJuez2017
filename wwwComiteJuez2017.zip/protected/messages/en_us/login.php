<?php
return array(
	'title'=>'PPOC Call for entries 2016 - Welcome',
	'loginFormHeader'=>'PPOC Call for entries 2016',
	'instrucciones'=>'Please provide your login credentials',
	'usuario'=>'Registered E-mail',
	'password'=>'Password',
	'olvidePass'=>'I Forgot my password',
	'necesitarCuenta'=>'I dont have an account',
	'facebook'=>'Login with Facebook',
	'errorInicio'=>'Wrong e-mail or password',
	'ingresar'=>'Login'
);