<?php
return array(
	'instrucciones'=>'In order to retrieve your password please provide us with your registration e-mail',
	'submit'=>'Retrieve Password',
		
);