<?php
return array(
	'talk'=>'Tell us about your issue',
	'tipoProblemaHeader'=>'What kind of issue did you experienced',
	'tipoProblema1'=>'Credit card payment via Paypal',
	'tipoProblema2'=>'Paypal Payment with my Account',	
	'tipoProblema3'=>'Loading Pictures',
	'tipoProblema4'=>'My problem isn\'t listed',
	'tipoProblema5'=>'',
	'descripcionProblema'=>'Please briefly decribe the issue',
	'submit'=>'Submit support ticket'
);