<?php
return array(
		'header'=>'Receipt summary',
		'headerCupon'=>'Cupons',
		'placeholderCupon'=>'Cupon Code',
		'headerTipoPago'=>'Payment Gateway',
		'totalAntesDeImpuesto'=>'Total before tax',
		'impuesto'=>'Tax',
		'total'=>'Total',
		'submit'=>'Make payment',
		'warningPay'=>'You must select a payment gateway'
		
		
);