<?php
return array(
	'place'=>'Place',
	'resolve'=>'Resolve'
);