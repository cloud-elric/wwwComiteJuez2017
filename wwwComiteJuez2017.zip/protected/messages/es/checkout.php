<?php
return array(
		'header'=>'REVISE SU PEDIDO',
		'headerCupon'=>'CUPONS',
		'placeholderCupon'=>'Cupon',
		'headerTipoPago'=>'PAYMENT GATEWAY',
		'total'=>'Total',
		'submit'=>'Make payment',
		'warningPay'=>'Debe seleccionar una forma de pago'
		
		
);