<?php
return array (
		'concursarBtn'=>'Concursar',
		'mensajeFinalizacion' => 'Tus materiales ya fueron ingresados
						al consurso - ¡Mucho Éxito!',
		'header'=>'Mis<span>Fotos</span>',
		'needHelp'=>'Necesito Ayuda',
		'headerModal'=>'Aviso',
		'warningMessage'=>'Al presionar este botón consursaras con las fotos en el estado en que se encuentran actualmente',
		'cancelBtn'=>'Mejor reviso que todo este completo',
		'successBtn'=>'Listo todos los datos estan completos',
		'loadImage'=>'Cargando imagen',
		'surferNoSupport'=>'Estas usando un navegador no soportado.'
);