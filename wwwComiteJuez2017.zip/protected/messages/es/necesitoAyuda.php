<?php
return array(
	'talk'=>'Hablanos del problema',
	'tipoProblemaHeader'=>'De que tipo fue el error que se te',
	'tipoProblema1'=>'Pago con tarjeta',
	'tipoProblema2'=>'Pago con ticket de pago',	
	'tipoProblema3'=>'Pago con Paypal',
	'tipoProblema4'=>'Cargando fotos',
	'tipoProblema5'=>'Otro',
	'descripcionProblema'=>'Relata brevemente el problema',
	'submit'=>'Reportar'
);