<?php
return array(
	'selectMostrar'=>'Number of finalists',
	'warningFinal'=>'These results are partial -- ',
	'conflicts'=>'There are some photos with missing categories, please resolve all conflicts',
	'incompleted'=>'The judging round is still in progress',
	'tieBreakerMessage'=>'Some photos are tied, please notify your judges about the tie-breaker round'
);