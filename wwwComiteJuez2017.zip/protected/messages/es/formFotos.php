<?php
return array (
		'edit' => 'Editar',
		'delete' => 'Eliminar',
		'uploadFoto'=>'Subir foto',
		'percentCompleted'=>'0% completado',
		'messageSuccess'=>'Fotografía guardada con éxito',
		'messageWarning'=>'Hay campos sin completar'
);