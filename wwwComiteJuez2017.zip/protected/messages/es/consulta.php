<?php
return array(
		'read'=>'Read Description',
		'description'=>'Description'
);